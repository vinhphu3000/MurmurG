If you're in a blank project, copy the TagManager.asset file into your
Unity Project Folder (not Assets/), replacing the existing TagManager.asset.

This installs the proper tags to run out-of-box AI setups.

Additionally, you can manually insert the tags into your project:

1) NoiseEmitter
2) JumpPoint
3) CoverSpot
4) Potion
5) Water
6) Food